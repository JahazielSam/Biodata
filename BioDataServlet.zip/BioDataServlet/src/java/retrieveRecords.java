/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author jahaziel_sam
 */
public class retrieveRecords extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            
            //CSS FOR THE WHOLE PAGE IN A PRINTLN() STATEMENT
            
            out.println("<style>\n" +
"    img{\n" +
"        margin-left: 20px;\n" +
"    }\n" +
"    \n" +
"h1{\n" +
"  font-size: 30px;\n" +
"  color: #fff;\n" +
"  text-transform: uppercase;\n" +
"  font-weight: 300;\n" +
"  text-align: center;\n" +
"  margin-bottom: 15px;\n" +
"}\n" +
"table{\n" +
"  width:100%;\n" +
"  padding: 0;\n" +
"  margin: 0;\n" +
"  table-layout: fixed;\n" +
"}\n" +
".tbl-header{\n" +
"  background-color: rgba(255,255,255,0.3);\n" +
" }\n" +
".tbl-content{\n" +
"  height:300px;\n" +
"  overflow-x:auto;\n" +
"  margin-top: 0px;\n" +
"  border: 1px solid rgba(255,255,255,0.3);\n" +
"}\n" +
"th{\n" +
"  padding: 20px 15px;\n" +
"  text-align: left;\n" +
"  font-weight: 500;\n" +
"  font-size: 12px;\n" +
"  color: #fff;\n" +
"  text-transform: uppercase;\n" +
"}\n" +
"td{\n" +
"  padding: 15px;\n" +
"  text-align: left;\n" +
"  vertical-align:middle;\n" +
"  font-weight: 300;\n" +
"  font-size: 12px;\n" +
"  color: #fff;\n" +
"  border-bottom: solid 1px rgba(255,255,255,0.1);\n" +
"  overflow: hidden; \n" +
"    text-overflow: ellipsis; \n" +
"    word-wrap: break-word;\n" +
"}\n" +
"\n" +
"\n" +
"/* demo styles */\n" +
"\n" +
"/*@import url(https://fonts.googleapis.com/css?family=Roboto:400,500,300,700);*/\n" +
"body{\n" +
"  background: -webkit-linear-gradient(left, #25c481, #25b7c4);\n" +
"  background: linear-gradient(to right, #25c481, #25b7c4);\n" +
"  font-family: 'Roboto', sans-serif;\n" +
"}\n" +
"section{\n" +
"  margin: 50px;\n" +
"}\n" +
"\n" +
"\n" +
"/* follow me template */\n" +
".made-with-love {\n" +
"  margin-top: 40px;\n" +
"  padding: 10px;\n" +
"  clear: left;\n" +
"  text-align: center;\n" +
"  font-size: 10px;\n" +
"  font-family: arial;\n" +
"  color: #fff;\n" +
"}\n" +
".made-with-love i {\n" +
"  font-style: normal;\n" +
"  color: #F50057;\n" +
"  font-size: 14px;\n" +
"  position: relative;\n" +
"  top: 2px;\n" +
"}\n" +
".made-with-love a {\n" +
"  color: #fff;\n" +
"  text-decoration: none;\n" +
"}\n" +
".made-with-love a:hover {\n" +
"  text-decoration: underline;\n" +
"}\n" +
"\n" +
"\n" +
"/* for custom scrollbar for webkit browser*/\n" +
"\n" +
"::-webkit-scrollbar {\n" +
"    width: 6px;\n" +
"} \n" +
"::-webkit-scrollbar-track {\n" +
"    -webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.3); \n" +
"} \n" +
"::-webkit-scrollbar-thumb {\n" +
"    -webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.3); \n" +
"}\n" +
"</style>");
            
            //HTML BLOCK OF THE SERVLET
            
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet retrieveRecords</title>");            
            out.println("</head>");
            out.println("<body>");
            try{
                //DATABASE CONNECTIVITY USING JDBC DRIVER
                
                Class.forName("com.mysql.jdbc.Driver");
                Connection conn=DriverManager.getConnection( "jdbc:mysql://localhost:3306/biodata","root","");
                Statement stmt=conn.createStatement();
                ResultSet rs = stmt.executeQuery("select * from data");
                
                out.println("<br>");
                
                //IMAGE TAG FOR HOME ICON & TABLE TAG FOR HEADINGS
                
                out.println("<a href=\"index.html\"><img src=\"whitehome.png\" width=\"50\" height=\"50\"></a>"
                        + "<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"rwd-table\" style=\"width:100%\">\n" +
"                    <tr>\n" +
"    <th>Name</th>\n" +
"    <th>Fathers Name</th> \n" +
"    <th>DOB</th>\n" +
"    <th>Gender</th>\n" +
"    <th>Qualification</th>\n" +
"    <th>Department</th>\n" +
"    <th>Address</th>\n" +
"    <th>City</th>\n" +
"    <th>PinCode</th>\n" +
"    <th>Mobile</th>\n" +
"    <th>Email</th>\n" +
"  </tr>");
                
                //RETRIEVING DATA FROM DATABASE USING WHILE LOOP WITH rs (resultSet) VARIABLE, WHICH HAS THE CONNECTIVITY DETAILS
                
                while(rs.next()){
                    out.print("<tr>");
                    
                    out.print("<td>");
                    out.print(rs.getString("name"));
                    out.print("</td>");
                    
                    out.print("<td>");
                    out.print(rs.getString("fname"));
                    out.print("</td>");
                    
                    out.print("<td>");
                    out.print(rs.getString("dob"));
                    out.print("</td>");
                    
                    out.print("<td>");
                    out.print(rs.getString("gender"));
                    out.print("</td>");
                    
                    out.print("<td>");
                    out.print(rs.getString("qualification"));
                    out.print("</td>");
                    
                    out.print("<td>");
                    out.print(rs.getString("dept"));
                    out.print("</td>");
                    
                    out.print("<td>");
                    out.print(rs.getString("address"));
                    out.print("</td>");
                    
                    out.print("<td>");
                    out.print(rs.getString("city"));
                    out.print("</td>");
                    
                    out.print("<td>");
                    out.print(rs.getString("pincode"));
                    out.print("</td>");
                    
                    out.print("<td>");
                    out.print(rs.getString("mobile"));
                    out.print("</td>");
                    
                    out.print("<td>");
                    out.print(rs.getString("email"));
                    out.print("</td>");
                    
                    out.print("</tr>");
                }
                out.print("</table>");
            }catch(Exception e){
                out.println("Error" + e);
            }
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
